import { readFile, writeFile } from 'node:fs/promises';
import { render } from '../.ssr/entry-server.js';
const page = await readFile('dist/index.html', 'utf8');
await writeFile('dist/index.html', page.replace('<!--app-html-->', render()));
console.log('Résumé rendered into static HTML; React hydrates interactive sections.');
