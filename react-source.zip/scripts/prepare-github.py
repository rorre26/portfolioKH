"""Package the built site for the existing GitHub Pages branch deployment."""
from pathlib import Path
import shutil
import zipfile

root = Path(__file__).resolve().parents[1]
target = root / 'output/github'
target.mkdir(parents=True, exist_ok=True)
# Keep the upload package aligned with this build, without obsolete bundles.
for pattern in ('index-*.js', 'index-*.css'):
    for bundle in (target / 'assets').glob(pattern):
        bundle.unlink()
shutil.copytree(root / 'dist', target, dirs_exist_ok=True)
shutil.copyfile(root / 'vendor/smoothui/LICENSE', target / 'assets/smoothui-license.txt')
(target / '.nojekyll').write_text('')
readme = '''# Интерактивное резюме

[Открыть сайт](https://rorre26.github.io/portfolioKH/)

Автоматизирую и оптимизирую процессы в течение четырёх лет.

Сайт на React, TypeScript и Vite: опыт работы, компетенции, примеры личного вклада, интерактивная карта WMS и скачиваемое резюме в PDF. При первом посещении доступен выбор русского или английского языка; выбор сохраняется, переключатель остаётся в шапке. У каждого языка отдельный двухстраничный PDF. Учитываются мобильные экраны, управление с клавиатуры и предпочтение уменьшения анимации.

Вступление MacBook Scroll показывает первый экран резюме внутри ноутбука. При прокрутке экран увеличивается до полного окна и открывает сайт. Экран и основание имеют общую петлю, согласованную ширину и синхронное масштабирование. Кнопка «Сразу к резюме» пропускает вступление; прямые ссылки на разделы и отключённые анимации открывают резюме сразу.

## Разработка

Исходный React-проект находится в `react-source.zip`. Архив содержит исходники, закреплённые зависимости, общие данные резюме, компоненты, ресурсы и лицензии; служебные файлы и зависимости в него не включены.

Распакуйте архив и выполните в папке проекта:

```sh
pnpm install --frozen-lockfile
pnpm run build
pnpm run preview
```

Для разработки используйте `pnpm run dev`. Предпросмотр доступен на `http://127.0.0.1:4173/`.

## Размещение

GitHub Pages публикует готовую сборку из корня ветки `main`. Файлы `index.html` и `assets/` созданы сборкой Vite с предварительной разметкой страницы; React подключает интерактивность после загрузки. Относительные адреса ресурсов поддерживают размещение в `/portfolioKH/`. Файл `.nojekyll` отключает обработку сборки Jekyll.

После изменений пересоберите проект, обновите исходный архив и перенесите содержимое `dist/` в корень репозитория. PDF для скачивания находятся в `public/assets/arif-khadikov-resume.pdf` и `public/assets/arif-khadikov-resume-en.pdf`; профессиональные сведения — в `src/resume.json` и `src/resume.en.json`. Генератор PDF требует Python, ReportLab, pypdf и DejaVu Sans; каталог шрифтов задаётся через `RESUME_FONT_DIR`. Для английского PDF используйте `python scripts/create-resume.py --lang=en`.

Использованы адаптированные компоненты [SmoothUI](https://github.com/educlopez/smoothui) по лицензии MIT. Исходники и лицензия сохранены в архиве (`vendor/smoothui/`); копия лицензии размещена в `assets/smoothui-license.txt`. Rubik распространяется по лицензии из `assets/font-license.txt`.

Детали ноутбука взяты из [Aceternity UI MacBook Scroll](https://ui.aceternity.com/components/macbook-scroll). Источник и описание адаптации находятся в `vendor/aceternity/README.md` в архиве исходников.
'''
(target / 'README.md').write_text(readme)
include = ['package.json', 'pnpm-lock.yaml', 'components.json', 'tsconfig.json', 'vite.config.ts', 'index.html', 'styles.css', 'server.mjs', '.gitignore', 'src', 'public', 'vendor', 'scripts/prerender.mjs', 'scripts/create-resume.py', 'scripts/prepare-github.py']
with zipfile.ZipFile(target / 'react-source.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for item in include:
        source = root / item
        for path in sorted(source.rglob('*')) if source.is_dir() else [source]:
            if not path.is_file():
                continue
            name = path.relative_to(root).as_posix()
            if name == 'scripts/create-resume.py':
                code = path.read_text().replace('import json, shutil', 'import json, shutil, os')
                start = code.index('fontroot=')
                end = code.index('\npdfmetrics.registerFont', start)
                code = code[:start] + "fontroot=Path(os.environ.get('RESUME_FONT_DIR', '/usr/share/fonts/truetype/dejavu'))" + code[end:]
                archive.writestr(name, code)
            else:
                archive.write(path, name)
    archive.writestr('README.md', readme)
print(f'Prepared {len(list(target.rglob("*")))} entries in {target}')
