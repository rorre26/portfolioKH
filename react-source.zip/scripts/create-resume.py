"""Generate the downloadable résumé from the site's shared, factual content."""
from pathlib import Path
from html import escape
import json, shutil, os, sys
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak, KeepTogether
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.colors import HexColor
from reportlab.lib.enums import TA_LEFT
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.pagesizes import A4
from pypdf import PdfReader
root=Path(__file__).resolve().parents[1]
lang = 'en' if '--lang=en' in sys.argv else 'ru'
data=json.loads((root/f'src/resume{".en" if lang == "en" else ""}.json').read_text())
labels = {
 'ru': {'experience':'Опыт работы','skills_projects':'Компетенции и проектный опыт','headline':'Ариф Хадиков / Автоматизация процессов','key_skills':'Ключевые компетенции','independent':'Самостоятельные проекты','tools':'Инструменты','education':'Образование','tools_prefix':'Инструменты: '},
 'en': {'experience':'Work experience','skills_projects':'Skills and project experience','headline':'Arif Khadikov / Process automation','key_skills':'Core skills','independent':'Independent projects','tools':'Tools','education':'Education','tools_prefix':'Tools: '}
}[lang]
fontroot=Path(os.environ.get('RESUME_FONT_DIR', '/usr/share/fonts/truetype/dejavu'))
pdfmetrics.registerFont(TTFont('Resume',str(fontroot/'DejaVuSans.ttf')))
pdfmetrics.registerFont(TTFont('ResumeBold',str(fontroot/'DejaVuSans-Bold.ttf')))
pdfmetrics.registerFontFamily('Resume',normal='Resume',bold='ResumeBold')
ink=HexColor('#202820');muted=HexColor('#5c655e');accent=HexColor('#b83d29')
styles={
 'name':ParagraphStyle('name',fontName='ResumeBold',fontSize=27,leading=32,textColor=ink,spaceAfter=8),
 'role':ParagraphStyle('role',fontName='ResumeBold',fontSize=13,leading=18,textColor=accent,spaceAfter=8),
 'body':ParagraphStyle('body',fontName='Resume',fontSize=9,leading=14,textColor=ink,spaceAfter=7),
 'meta':ParagraphStyle('meta',fontName='Resume',fontSize=8,leading=12,textColor=muted,spaceAfter=5),
 'section':ParagraphStyle('section',fontName='ResumeBold',fontSize=12,leading=16,textColor=accent,spaceBefore=15,spaceAfter=10),
 'job':ParagraphStyle('job',fontName='ResumeBold',fontSize=11,leading=16,textColor=ink,spaceAfter=5),
 'bullet':ParagraphStyle('bullet',fontName='Resume',fontSize=9,leading=14,textColor=ink,leftIndent=12,firstLineIndent=-9,spaceAfter=5),
}
def txt(value):return escape(value.replace('—','-').replace('–','-').replace('·',' / '))
def para(value,style='body'):return Paragraph(txt(value),styles[style])
filename=f'arif-khadikov-resume{"-en" if lang == "en" else ""}.pdf'
output=root/'output/pdf'/filename;output.parent.mkdir(parents=True,exist_ok=True)
story=[para(data['name'],'name'),para(data['title'],'role'),Paragraph(f'<link href="mailto:{data["email"]}">{data["email"]}</link>',styles['body']),para(data['experience'],'meta'),para(data['summary']),para(labels['experience'],'section')]
for job in data['jobs']:
    story.append(KeepTogether([para(job['company'],'job'),para(f'{job["period"]} | {job["role"]}','meta'),para(job['domain'],'meta')]))
    story.append(para(job['scope']))
    for item in job['achievements']:story.append(para('- '+item,'bullet'))
    story.append(para(labels['tools_prefix']+', '.join(job['tools']),'meta'))
story += [PageBreak(),para(labels['skills_projects'],'name'),para(labels['headline'],'meta'),para(labels['key_skills'],'section')]
for skill in data['skills']:story += [para(skill['title'],'job'),para(skill['text'])]
story.append(para(labels['independent'],'section'))
for item in data['independent']:
    story.append(KeepTogether([para(item['title'],'job'),para(item['text'])]))
story += [para(labels['tools'],'section'),para(', '.join(data['tools'])),para(data['additional']),para(labels['education'],'section'),para(data['education']['school'],'job'),para(data['education']['degree'])]
def footer(canvas,doc):
    canvas.setStrokeColor(HexColor('#d8ddd7'));canvas.line(42,39,A4[0]-42,39)
    canvas.setFont('Resume',7);canvas.setFillColor(muted)
    canvas.drawString(42,26,labels['headline'])
    canvas.drawRightString(A4[0]-42,26,f'{doc.page} / 2')
doc=SimpleDocTemplate(str(output),pagesize=A4,leftMargin=42,rightMargin=42,topMargin=38,bottomMargin=52,title=data['name']+' - '+data['title'],author=data['name'])
doc.build(story,onFirstPage=footer,onLaterPages=footer)
reader=PdfReader(output)
assert len(reader.pages)==2, f'Expected 2 pages, got {len(reader.pages)}'
text='\n'.join(p.extract_text() for p in reader.pages)
for term in (['Arif Khadikov','300+','February 2025','20+','Basic SQL'] if lang == 'en' else ['Ариф Хадиков','300+','Февраль 2025','20+','Базовый SQL']):
    assert term in text,term
(root/'qa').mkdir(exist_ok=True)
(root/f'qa/resume-pdf-text{".en" if lang == "en" else ""}.txt').write_text(text)
shutil.copyfile(output,root/'public/assets'/filename)
print(f'Created {len(reader.pages)} pages: {output}')
