import { createRoot, hydrateRoot } from 'react-dom/client';
import App from './App';
import './theme.css';
import '../styles.css';
import './resume.css';
const root = document.getElementById('root')!;
if (root.hasChildNodes() && root.querySelector('main')) hydrateRoot(root, <App />);
else createRoot(root).render(<App />);
