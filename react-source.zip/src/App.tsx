import { useEffect, useRef, useState } from 'react';
import { motion, useScroll } from 'motion/react';
import type { ProjectKey } from './data';
import { MotionProvider } from './lib/motion';
import Header from './components/Header';
import MacbookIntro from './components/MacbookIntro';
import Hero from './components/Hero';
import WmsExplorer from './components/WmsExplorer';
import ProjectGallery from './components/ProjectGallery';
import CaseModal from './components/CaseModal';
import Contact from './components/Contact';
import { About, Experience, Skills, Education } from './components/StaticSections';
import { LocaleProvider, useLocale } from './locale';
function Portfolio() {
  const {t}=useLocale();
  const [project,setProject]=useState<ProjectKey|null>(null);const wms=useRef<HTMLDetailsElement>(null);
  const {scrollYProgress}=useScroll();
  const openWms=()=>{if(wms.current){wms.current.open=true;wms.current.scrollIntoView({block:'start',behavior:document.documentElement.dataset.motion==='off'?'instant':'smooth'});wms.current.querySelector('summary')?.focus({preventScroll:true});}};
  useEffect(()=>{const handle=()=>{if(location.hash==='#wms-title'||location.hash==='#wms-details'){wms.current!.open=true;}if(location.hash==='#independent-projects'){const node=document.querySelector<HTMLDetailsElement>('.independent-experience');if(node){node.open=true;node.querySelector('summary')?.focus({preventScroll:true});}}};handle();window.addEventListener('hashchange',handle);return()=>window.removeEventListener('hashchange',handle);},[]);
  return <><motion.div className="scroll-progress" aria-hidden="true" style={{scaleX:scrollYProgress}}/><MacbookIntro><Header/><main id="main" tabIndex={-1}><Hero/><About onOpen={setProject}/><Experience onOpen={setProject} onWms={openWms}/><Skills onOpen={setProject} onWms={openWms}/>
    <section id="projects" className="projects container section-space resume-projects"><div className="resume-section-head"><p className="eyebrow">{t('[03] / ПРИМЕРЫ МОЕГО ВКЛАДА')}</p><h2>{t('Опыт, подтверждённый работой.')}</h2><p>{t('Мои действия, ответственность и результаты в конкретных задачах.')}</p></div>
      <details className="resume-wms" id="wms-details" ref={wms}><summary><span><span className="eyebrow">{t('01 / АЙКОВЕР ПРО')}</span><strong>{t('Проектирование и запуск WMS')}</strong><span>{t('Архитектура, требования и сценарии. Приёмка работает на одном складе.')}</span></span><span className="disclosure-plus" aria-hidden="true">+</span></summary><WmsExplorer/></details><ProjectGallery onOpen={setProject}/>
    </section><Education/><Contact/></main></MacbookIntro><CaseModal project={project} onClose={()=>setProject(null)} onChange={setProject}/></>;
}
export default function App(){return <MotionProvider><LocaleProvider><Portfolio/></LocaleProvider></MotionProvider>}
