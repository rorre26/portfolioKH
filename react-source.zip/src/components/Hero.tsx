import resume from '../resume.json';
import MaskRevealUp from './smoothui/MaskRevealUp';
export default function Hero() {
  return <section id="top" className="hero resume-hero"><div className="container">
    <div className="hero-topline"><p className="eyebrow"><span className="status-dot" /> ПРОФЕССИОНАЛЬНОЕ РЕЗЮМЕ</p><span className="eyebrow hero-edition">АВТОМАТИЗАЦИЯ / ОПТИМИЗАЦИЯ</span></div>
    <div className="resume-hero-grid"><div className="resume-intro">
      <h1><MaskRevealUp lines={['АРИФ', 'ХАДИКОВ']} /></h1>
      <p className="resume-role">{resume.experience}</p><p className="resume-summary">{resume.summary}</p>
      <div className="resume-actions"><a className="action-button" href="#experience">Посмотреть опыт <span aria-hidden="true">↘</span></a><a className="text-link" href={`mailto:${resume.email}?subject=Предложение%20о%20работе`}>Обсудить вакансию <span aria-hidden="true">↗</span></a></div>
      <a className="resume-download" href="assets/arif-khadikov-resume.pdf" download>Скачать резюме <span>PDF · 2 страницы ↓</span></a>
    </div><aside className="candidate-card" aria-label="Краткий профессиональный профиль">
      <div className="candidate-card-top"><span className="eyebrow">ПРОФЕССИОНАЛЬНЫЙ ПРОФИЛЬ</span><span className="candidate-mark" aria-hidden="true">ах.</span></div>
      <div className="candidate-tenure"><strong>4</strong><p>года автоматизирую<br />и оптимизирую процессы</p></div>
      <dl><div><dt>Опыт в компании</dt><dd>Айковер ПРО<span>С февраля 2025</span></dd></div><div><dt>Основные задачи</dt><dd>Автоматизация и оптимизация процессов</dd></div><div><dt>Рабочий контекст</dt><dd>Бизнес-заказчики, пользователи и команда разработки</dd></div><div><dt>Образование</dt><dd>Прикладная информатика<span>РЭУ им. Г. В. Плеханова</span></dd></div></dl>
    </aside></div><div className="hero-foot"><span className="eyebrow">ОПЫТ · КОМПЕТЕНЦИИ · ЛИЧНЫЙ ВКЛАД</span><a href="#experience" aria-label="Перейти к опыту работы">↓</a></div>
  </div></section>;
}
