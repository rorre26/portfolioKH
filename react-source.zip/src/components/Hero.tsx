import MaskRevealUp from './smoothui/MaskRevealUp';
import { useLocale } from '../locale';
export default function Hero({ preview = false }: { preview?: boolean }) {
  const {locale,t,resume}=useLocale();
  const NameTag = preview ? 'div' : 'h1';
  return <section id={preview ? undefined : 'top'} className="hero resume-hero"><div className="container">
    <div className="hero-topline"><p className="eyebrow"><span className="status-dot" /> {t('ПРОФЕССИОНАЛЬНОЕ РЕЗЮМЕ')}</p><span className="eyebrow hero-edition">{t('АВТОМАТИЗАЦИЯ / ОПТИМИЗАЦИЯ')}</span></div>
    <div className="resume-hero-grid"><div className="resume-intro">
      <NameTag className={preview ? 'intro-preview-name' : undefined}>{preview ? <span className="smooth-mask">{(locale==='en'?['ARIF','KHADIKOV']:['АРИФ','ХАДИКОВ']).map(line=><span className="smooth-mask-window" key={line}><span className="smooth-mask-line">{line}</span></span>)}</span> : <MaskRevealUp lines={locale==='en'?['ARIF','KHADIKOV']:['АРИФ','ХАДИКОВ']} />}</NameTag>
      <p className="resume-role">{resume.experience}</p><p className="resume-summary">{resume.summary}</p>
      <div className="resume-actions"><a className="action-button" href="#experience">{t('Посмотреть опыт')} <span aria-hidden="true">↘</span></a><a className="text-link" href={`mailto:${resume.email}?subject=${encodeURIComponent(t('Предложение о работе'))}`}>{t('Обсудить вакансию')} <span aria-hidden="true">↗</span></a></div>
      <a className="resume-download" href={`assets/arif-khadikov-resume${locale==='en'?'-en':''}.pdf`} download>{t('Скачать резюме')} <span>{t('PDF · 2 страницы ↓')}</span></a>
    </div><aside className="candidate-card" aria-label={locale==='en'?'Professional profile':'Краткий профессиональный профиль'}>
      <div className="candidate-card-top"><span className="eyebrow">{t('ПРОФЕССИОНАЛЬНЫЙ ПРОФИЛЬ')}</span><span className="candidate-mark" aria-hidden="true">{locale==='en'?'ak.':'ах.'}</span></div>
      <div className="candidate-tenure"><strong>4</strong><p>{t('года автоматизирую')}<br />{t('и оптимизирую процессы')}</p></div>
      <dl><div><dt>{t('Опыт в компании')}</dt><dd>{t('Айковер ПРО')}<span>{t('С февраля 2025')}</span></dd></div><div><dt>{t('Основные задачи')}</dt><dd>{t('Автоматизация и оптимизация процессов')}</dd></div><div><dt>{t('Рабочий контекст')}</dt><dd>{t('Бизнес-заказчики, пользователи и команда разработки')}</dd></div><div><dt>{t('Образование')}</dt><dd>{t('Прикладная информатика')}<span>{t('РЭУ им. Г. В. Плеханова')}</span></dd></div></dl>
    </aside></div><div className="hero-foot"><span className="eyebrow">{t('ОПЫТ · КОМПЕТЕНЦИИ · ЛИЧНЫЙ ВКЛАД')}</span><a href="#experience" aria-label={t('Перейти к опыту работы')}>↓</a></div>
  </div></section>;
}
