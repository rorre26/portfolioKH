import { useEffect, useRef, useState } from 'react';
import { email } from '../data';
import { useMotionSettings } from '../lib/motion';
import ButtonCopy from './smoothui/ButtonCopy';
export default function Contact() {
  const { enabled, systemReduced, toggle } = useMotionSettings();
  const [message, setMessage] = useState('');
  const address = useRef<HTMLAnchorElement>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  useEffect(() => () => clearTimeout(timer.current), []);
  const notify = (text: string) => { setMessage(text); clearTimeout(timer.current); timer.current = setTimeout(() => setMessage(''), 3000); };
  const copy = async () => {
    try { await navigator.clipboard.writeText(email); notify('Почта скопирована'); }
    catch (error) {
      const range = document.createRange(); range.selectNodeContents(address.current!);
      const selection = window.getSelection(); selection?.removeAllRanges(); selection?.addRange(range);
      notify('Выделил почту — скопируйте её вручную'); throw error;
    }
  };
  return <><section id="contact" className="contact"><div className="container">
    <div className="contact-top eyebrow"><span>[04] / КОНТАКТ</span><span>ОБСУДИМ РОЛЬ В ВАШЕЙ КОМАНДЕ</span></div>
    <a className="contact-title" href={`mailto:${email}`}><h2>ОБСУДИМ<br />ВАКАНСИЮ<span>.</span></h2><span className="contact-arrow" aria-hidden="true">↗</span></a>
    <a className="contact-resume text-link" href="assets/arif-khadikov-resume.pdf" download>Скачать резюме в PDF ↓</a><div className="contact-bottom"><p>Готов обсудить задачи по автоматизации<br />и оптимизации процессов в вашей команде.</p><div className="email-actions">
      <a ref={address} className="email-link" href={`mailto:${email}`}>{email}</a><ButtonCopy className="copy-email" onCopy={copy} />
    </div></div><footer className="footer"><a href="#top">Ариф Хадиков / Автоматизация процессов</a>
      <button id="motion-toggle" aria-pressed={enabled} disabled={systemReduced} onClick={toggle}>{systemReduced ? 'Движение: снижено' : `Движение: ${enabled ? 'вкл' : 'выкл'}`}</button><a href="#top">В начало ↑</a>
    </footer></div></section><div id="toast" className={`toast${message ? ' visible' : ''}`} role="status" aria-live="polite">{message}</div></>;
}
