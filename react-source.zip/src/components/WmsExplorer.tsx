import { useState } from 'react';
import { motion } from 'motion/react';
import { modules, stages, type ModuleKey } from '../data';
import { navigateTabs } from '../lib/tabs';
import { Reveal, usePanelTransition } from './motion';
import { SystemMapArt } from './ProjectArt';
import AnimatedTabs from './smoothui/AnimatedTabs';
const moduleKeys = Object.keys(modules) as ModuleKey[];
const stageKeys = ['requirements', 'design', 'launch'];
export default function WmsExplorer() {
  const [selected, setSelected] = useState<ModuleKey>('inbound');
  const [stage, setStage] = useState('requirements');
  const transition = usePanelTransition();
  const item = modules[selected], step = stages[stageKeys.indexOf(stage)];
  return <Reveal className="wms-feature reveal"><article aria-labelledby="wms-title">
    <div className="wms-heading"><div><p className="eyebrow">[01 / 05] АЙКОВЕР ПРО / СКЛАДСКАЯ ЛОГИСТИКА</p><h3 id="wms-title">WMS с нуля<span>.</span></h3></div><p>Спроектировал архитектуру и пользовательские сценарии системы управления складом. Сопровождал запуск первого модуля в продуктив.</p></div>
    <div className="wms-explorer"><div className="system-map" data-module={selected}>
      <div className="map-topline eyebrow"><span>КАРТА МОДУЛЕЙ</span><span>НАЖМИТЕ НА УЗЕЛ ↙</span></div>
      <div className="map-canvas"><SystemMapArt /><div className="map-hub" aria-hidden="true"><strong>WMS</strong><span>СИСТЕМА</span></div>
        <div className="module-tabs" role="tablist" aria-label="Модули WMS">{moduleKeys.map(key => {
          const node = modules[key];
          return <button id={`module-${key}`} key={key} data-key={key} data-module={key} className={`module-node node-${key}`}
            role="tab" aria-selected={selected === key} aria-controls="module-panel" tabIndex={selected === key ? 0 : -1}
            onClick={() => setSelected(key)} onKeyDown={event => navigateTabs(event, moduleKeys, key, setSelected)}>
            <span className="node-index">{node.number} <i className={`module-dot ${node.state}`} /></span><strong>{node.title}</strong><span className="node-status">{key === 'outbound' ? 'ТЕСТИРОВАНИЕ' : node.status.toUpperCase()}</span>
          </button>;
        })}</div></div><div className="map-footer eyebrow"><span>ЧЕТЫРЕ МОДУЛЯ / ОДНА СИСТЕМА</span><span>СХЕМА ПРОЕКТА</span></div>
    </div><motion.div key={selected} {...transition} id="module-panel" className="module-panel" role="tabpanel" aria-labelledby={`module-${selected}`} tabIndex={0} aria-live="polite">
      <div className="module-panel-top"><span id="module-number" className="eyebrow">МОДУЛЬ / {item.number}</span><span id="module-status" className="status-label" data-status={item.state}>{item.status}</span></div>
      <h4 id="module-title">{item.title}</h4><p id="module-description">{item.description}</p>
      <div className="module-fact"><strong id="module-value">{item.value}</strong><span id="module-value-label">{item.valueLabel}</span></div>
      <div className="module-context"><p className="eyebrow">МОЙ ВКЛАД В WMS</p><p>Архитектура системы, требования и пользовательские сценарии в BPMN, UML и DFD. Сопровождение запуска первого модуля.</p></div>
    </motion.div></div>
    <div className="wms-method"><div><p className="eyebrow">ОТ ТРЕБОВАНИЙ ДО ЗАПУСКА</p>
      <AnimatedTabs className="stage-tabs" ariaLabel="Этапы проекта WMS" panelId="stage-panel" layoutId="wms-stages" activeTab={stage} onChange={setStage}
        tabs={['01. Требования', '02. Решение', '03. Запуск'].map((label, index) => ({ id: stageKeys[index], label }))} />
    </div><motion.div key={stage} {...transition} id="stage-panel" className="stage-panel" role="tabpanel" aria-labelledby={`wms-stages-tab-${stage}`} tabIndex={0}>
      <h4 id="stage-title">{step.title}</h4><p id="stage-text">{step.text}</p>
    </motion.div></div>
  </article></Reveal>;
}
