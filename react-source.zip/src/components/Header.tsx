import { useEffect, useRef, useState } from 'react';
export default function Header() {
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState('');
  const toggle = useRef<HTMLButtonElement>(null);
  useEffect(() => {
    const close = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && open) { setOpen(false); toggle.current?.focus(); }
    };
    const width = window.matchMedia('(min-width: 700px)');
    const reset = () => setOpen(false);
    document.addEventListener('keydown', close); width.addEventListener('change', reset);
    return () => { document.removeEventListener('keydown', close); width.removeEventListener('change', reset); };
  }, [open]);
  useEffect(() => {
    let frame = 0;
    const update = () => {
      frame = 0; let id = '';
      ['experience', 'skills', 'projects'].forEach(key => {
        if (document.getElementById(key)!.getBoundingClientRect().top < innerHeight * 0.4) id = key;
      }); setActive(id);
    };
    const schedule = () => { if (!frame) frame = requestAnimationFrame(update); };
    update(); window.addEventListener('scroll', schedule, { passive: true }); window.addEventListener('resize', schedule);
    return () => { cancelAnimationFrame(frame); window.removeEventListener('scroll', schedule); window.removeEventListener('resize', schedule); };
  }, []);
  const links = [['experience', 'Опыт'], ['skills', 'Компетенции'], ['projects', 'Мой вклад']];
  return <header className="site-header"><div className="container nav-wrap">
    <a className="identity" href="#top" aria-label="Ариф Хадиков — в начало"><span className="monogram">ах.</span><span className="identity-name">АРИФ ХАДИКОВ<span>АВТОМАТИЗАЦИЯ ПРОЦЕССОВ</span></span></a>
    <nav className="desktop-nav" aria-label="Основная навигация">{links.map(([key, label], i) =>
      <a key={key} href={`#${key}`} className={active === key ? 'is-current' : undefined} aria-current={active === key ? 'location' : undefined}>[0{i + 1}] {label}</a>)}</nav>
    <a className="nav-contact" href="#contact">Связаться <span aria-hidden="true">↗</span></a>
    <button ref={toggle} className="menu-toggle" aria-label={open ? 'Закрыть меню' : 'Открыть меню'}
      aria-expanded={open} aria-controls="mobile-nav" onClick={() => setOpen(!open)}><span /><span /></button>
  </div><nav id="mobile-nav" className="mobile-nav" aria-label="Мобильная навигация" hidden={!open}>
    {[...links, ['contact', 'Связаться']].map(([key, label], i) => <a key={key} href={`#${key}`} onClick={() => setOpen(false)}>{label} <span>[0{i + 1}]</span></a>)}
  </nav></header>;
}
