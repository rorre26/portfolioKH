import { motion } from 'motion/react';
import type { ReactNode } from 'react';
import { useReducedPortfolioMotion } from '../lib/motion';
export function Reveal({ children, className }: { children: ReactNode; className?: string }) {
  const reduced = useReducedPortfolioMotion();
  return <motion.div className={className} initial={reduced ? false : { opacity: 0, y: 16 }}
    whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: 0.06 }}
    animate={reduced ? { opacity: 1, y: 0 } : undefined}
    transition={{ duration: reduced ? 0 : 0.3, ease: [0.22, 1, 0.36, 1] }}>{children}</motion.div>;
}
export function usePanelTransition() {
  const reduced = useReducedPortfolioMotion();
  return {
    initial: reduced ? false as const : { opacity: 0, y: 7 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: reduced ? 0 : 0.2 },
  };
}
