import { useState } from 'react';
import { motion } from 'motion/react';
import resume from '../resume.json';
import { usePanelTransition } from './motion';
import type { ProjectKey } from '../data';
import AnimatedTabs from './smoothui/AnimatedTabs';
export function About({ onOpen }: { onOpen: (key: ProjectKey) => void }) {
  return <section id="about" className="resume-facts container"><p className="eyebrow">ЛИЧНЫЙ ВКЛАД В ЦИФРАХ</p><div className="resume-fact-grid">
    <a href="#experience"><strong>~50</strong><span>описанных процессов</span><small>За год в Айковер ПРО</small></a>
    <a href="#experience"><strong>~30</strong><span>технических заданий</span><small>За год в Айковер ПРО</small></a>
    <button onClick={() => onOpen('hr')}><strong>300+</strong><span>пользователей внедрённого HR-сервиса</span><small>Мой вклад и результат ↗</small></button>
  </div></section>;
}
export function Experience({ onOpen, onWms }: { onOpen: (key: ProjectKey) => void; onWms: () => void }) {
  return <section id="experience" className="experience section-space resume-experience"><div className="container">
    <div className="resume-section-head"><p className="eyebrow">[01] / ОПЫТ РАБОТЫ</p><h2>Опыт и ответственность.</h2><p>{resume.experience} {resume.domains}.</p></div>
    <div className="resume-jobs">{resume.jobs.map((job,i) => <article className="resume-job" key={job.company}>
      <div className="resume-job-meta"><p className="eyebrow">{job.period}</p><h3>{job.company}</h3><p className="job-role">{job.role}</p><p className="resume-domain">{job.domain}</p></div>
      <div className="resume-job-copy"><p className="resume-label">ЗОНА ОТВЕТСТВЕННОСТИ</p><p>{job.scope}</p><p className="resume-label">МОЙ ВКЛАД</p><ul>{job.achievements.slice(0,i===0?2:3).map(text => <li key={text}>{text}</li>)}</ul>
        {i===0 && <details className="resume-more"><summary>Ещё достижения</summary><ul>{job.achievements.slice(2).map(text => <li key={text}>{text}</li>)}</ul></details>}
        <div className="tags">{job.tools.map(tag => <span key={tag}>{tag}</span>)}</div><div className="resume-job-links">{i===0 ? <><button className="text-link" onClick={onWms}>Мой вклад в WMS ↗</button><button className="text-link" onClick={() => onOpen('hr')}>Внедрение HR-сервиса ↗</button></> : <button className="text-link" onClick={() => onOpen('procurement')}>Подробнее о внедрении ↗</button>}</div>
      </div></article>)}</div>
    <details className="independent-experience" id="independent-projects"><summary><span><span className="eyebrow">ОТДЕЛЬНЫЙ ПРОЕКТНЫЙ ОПЫТ</span><strong>Самостоятельные проекты</strong><span>Банковские системы, EAM, HR и автоматизация бизнеса</span></span><span className="disclosure-plus" aria-hidden="true">+</span></summary><div className="independent-list">{resume.independent.map(item => <article key={item.title}><h3>{item.title}</h3><p>{item.text}</p></article>)}</div></details>
  </div></section>;
}
const evidence = [
  {id:'requirements',label:'Требования',title:'20+ интервью в банковском проекте',text:'Собирал требования, спроектировал интеграцию с 1С Документооборот, подготовил инструкции и участвовал в тестировании.',action:'Банковский документооборот — в проектном опыте'},
  {id:'design',label:'Проектирование',title:'Архитектура и сценарии WMS',text:'Проработал требования и пользовательские сценарии в BPMN, UML и DFD. Сопровождал запуск приёмки на одном складе.',action:'Посмотреть мой вклад в WMS ↗'},
  {id:'adoption',label:'Внедрение',title:'Обучение 30 сотрудников',text:'Спроектировал и внедрил согласование закупочных договоров в 1С Документооборот. Обучил сотрудников новым процессам и сценариям.',action:'Открыть пример внедрения ↗'}
];
export function Skills({onOpen,onWms}: {onOpen:(key:ProjectKey)=>void;onWms:()=>void}) {
  const [selected,setSelected]=useState('requirements'); const item=evidence.find(x=>x.id===selected)!; const transition=usePanelTransition();
  return <section id="skills" className="skills container section-space resume-skills"><div className="resume-section-head"><p className="eyebrow">[02] / КОМПЕТЕНЦИИ</p><h2>Задачи, которые беру на себя.</h2></div>
    <div className="resume-skill-grid">{resume.skills.map((skill,i)=><article key={skill.title}><span className="eyebrow">0{i+1}</span><h3>{skill.title}</h3><p>{skill.text}</p><div className="tags">{skill.tags.map(tag=><span key={tag}>{tag}</span>)}</div></article>)}</div>
    <div className="competency-proof"><div className="competency-proof-control"><p className="eyebrow">ПОДТВЕРЖДЕНИЕ ИЗ ОПЫТА</p><AnimatedTabs tabs={evidence} activeTab={selected} onChange={setSelected} layoutId="competency" panelId="competency-panel" ariaLabel="Примеры применения компетенций" variant="underline" className="competency-tabs" /></div>
      <motion.div {...transition} key={selected} id="competency-panel" role="tabpanel" aria-labelledby={`competency-tab-${selected}`}><h3>{item.title}</h3><p>{item.text}</p>{selected==='requirements' ? <a className="text-link" href="#independent-projects">{item.action}</a> : <button className="text-link" onClick={selected==='design'?onWms:()=>onOpen('procurement')}>{item.action}</button>}</motion.div>
    </div><div className="toolbox"><span className="eyebrow">ИНСТРУМЕНТЫ В РАБОТЕ</span><div className="tool-list">{resume.tools.map(tool=><span key={tool}>{tool}</span>)}</div></div><p className="resume-additional">Дополнительно: {resume.additional}</p>
  </section>;
}
export function Education(){return <section className="resume-education container section-space" id="education"><p className="eyebrow">ОБРАЗОВАНИЕ</p><div><h2>{resume.education.school}</h2><p>{resume.education.degree}</p></div></section>}
