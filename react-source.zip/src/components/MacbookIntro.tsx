import { useEffect, useRef, useState, type ReactNode } from 'react';
import { motion, useMotionValue, useTransform } from 'motion/react';
import { Keypad, SpeakerGrid, Trackpad } from './ui/macbook-scroll';
import Header from './Header';
import Hero from './Hero';
import { useLocale } from '../locale';
import { useMotionSettings } from '../lib/motion';

// The original Aceternity keyboard and chassis details are reused here. The
// scroll choreography is adapted to hand off to the actual résumé at 1:1 size.
export default function MacbookIntro({ children }: { children: ReactNode }) {
  const { locale, pending, t } = useLocale();
  const { enabled } = useMotionSettings();
  const [ready, setReady] = useState(false);
  const [direct, setDirect] = useState(false);
  const [entered, setEntered] = useState(false);
  const [viewport, setViewport] = useState({ width: 1440, height: 900 });
  const runway = useRef<HTMLElement>(null);
  const focusOnEntry = useRef(false);
  const progress = useMotionValue(0);
  const active = ready && enabled && !direct;
  const en = locale === 'en';

  useEffect(() => {
    // Shared links and browser history should open the requested résumé section.
    setDirect(Boolean(window.location.hash));
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready || !direct || pending) return;
    // Language hydration can change section heights after the browser's initial
    // anchor jump. Align once the selected language and document layout agree.
    const frame = requestAnimationFrame(() => {
      let id = window.location.hash.slice(1);
      try { id = decodeURIComponent(id); } catch { /* Keep malformed links harmless. */ }
      document.getElementById(id)?.scrollIntoView({ block: 'start', behavior: 'instant' });
    });
    return () => cancelAnimationFrame(frame);
  }, [ready, direct, pending, locale]);

  useEffect(() => {
    if (!active) return;
    let frame = 0;
    const update = () => {
      frame = 0;
      const section = runway.current;
      if (!section) return;
      const length = section.offsetHeight - window.innerHeight;
      const value = length > 0 ? Math.min(1, Math.max(0, -section.getBoundingClientRect().top / length)) : 1;
      progress.set(value);
      setEntered(value >= 1);
    };
    const schedule = () => { if (!frame) frame = requestAnimationFrame(update); };
    const resize = () => {
      setViewport({ width: document.documentElement.clientWidth, height: window.innerHeight });
      schedule();
    };
    resize();
    window.addEventListener('scroll', schedule, { passive: true });
    window.addEventListener('resize', resize);
    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener('scroll', schedule);
      window.removeEventListener('resize', resize);
    };
  }, [active, progress]);

  useEffect(() => {
    if (entered && focusOnEntry.current) {
      document.getElementById('main')?.focus({ preventScroll: true });
      focusOnEntry.current = false;
    }
  }, [entered]);

  const deviceWidth = Math.min(viewport.width * .74, 760, viewport.height * .72);
  const startY = Math.max(145, (viewport.height - deviceWidth * .92) / 2);
  const scale = useTransform(progress, [0, .18, 1], [deviceWidth / viewport.width, deviceWidth / viewport.width, 1]);
  const rotateX = useTransform(progress, [0, .5, 1], [-25, 0, 0]);
  const height = useTransform(progress, [0, 1], [viewport.width * .625, viewport.height]);
  // Both panels meet at the same hinge in the same perspective space. Their
  // physical widths stay equal while the screen grows to the full viewport.
  const hingeY = useTransform(progress, [0, .18, 1], [startY + deviceWidth * .625, startY + deviceWidth * .625, viewport.height]);
  const screenY = useTransform(() => hingeY.get() - height.get());
  const baseScale = useTransform(scale, value => value * viewport.width / 512);
  const perspectiveOrigin = useTransform(hingeY, value => `50% ${value}px`);
  const contentScale = useTransform(progress, [0, .8, 1], [viewport.width < 700 ? .5 : 1, 1, 1]);
  const contentWidth = useTransform(contentScale, value => viewport.width / value);
  const radius = useTransform(progress, [.5, 1], [18, 0]);
  const chromeOpacity = useTransform(progress, [.4, .9], [1, 0]);
  const baseOpacity = useTransform(progress, [.25, .62], [1, 0]);
  const copyOpacity = useTransform(progress, [0, .25], [1, 0]);

  const skip = () => {
    const section = runway.current;
    if (!section) return;
    focusOnEntry.current = true;
    window.scrollTo({ top: window.scrollY + section.getBoundingClientRect().top + section.offsetHeight - window.innerHeight, behavior: 'instant' });
  };

  return <div className={`macbook-entry${active ? ' is-active' : ''}${entered ? ' is-entered' : ''}`}>
    <a className="skip-link" href="#main" onClick={event => { if (active && !entered) { event.preventDefault(); skip(); } }}>{t('Перейти к содержанию')}</a>
    <section ref={runway} className="macbook-runway" aria-label={en ? 'An introduction to my résumé' : 'Знакомство с резюме'}>
      <div className="macbook-stage">
        <motion.div className="macbook-intro-copy" style={{ opacity: copyOpacity }}>
          <p className="eyebrow">{en ? 'ARIF KHADIKOV / RÉSUMÉ' : 'АРИФ ХАДИКОВ / РЕЗЮМЕ'}</p>
          <p>{en ? 'A closer look at my experience.' : 'Познакомимся поближе.'}</p>
        </motion.div>
        <motion.div className="macbook-device" style={{ perspective: deviceWidth * 6, perspectiveOrigin }} aria-hidden="true" inert>
          <motion.div className="macbook-base" style={{ y: hingeY, opacity: baseOpacity, scale: baseScale, rotateX: 58 }}>
            <div className="macbook-hinge" />
            <div className="macbook-keyboard"><div><SpeakerGrid /></div><div><Keypad /></div><div><SpeakerGrid /></div></div>
            <Trackpad />
            <div className="macbook-notch" />
          </motion.div>
          <motion.div className="macbook-screen" style={{ scale, y: screenY, rotateX, height, borderRadius: radius }}>
            <motion.div className="macbook-screen-content" style={{ scale: contentScale, width: contentWidth }}><Header preview /><Hero preview /></motion.div>
            <motion.div className="macbook-screen-frame" style={{ opacity: chromeOpacity }}><span /></motion.div>
          </motion.div>
        </motion.div>
        <div className="macbook-intro-controls">
          <motion.span className="eyebrow" style={{ opacity: copyOpacity }}>{en ? 'SCROLL TO EXPLORE' : 'ПРОКРУТИТЕ, ЧТОБЫ ОТКРЫТЬ'} <span aria-hidden="true">↓</span></motion.span>
          <button type="button" onClick={skip} tabIndex={active && !entered ? 0 : -1}>{en ? 'Go to résumé' : 'Сразу к резюме'} <span aria-hidden="true">↗</span></button>
        </div>
      </div>
    </section>
    <div className="resume-document" inert={active && !entered}>{children}</div>
  </div>;
}
