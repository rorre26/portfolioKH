// Adapted from SmoothUI mask-reveal-up (MIT): original typography and shorter timing.
import { motion, useInView } from 'motion/react';
import { useRef, type ReactNode } from 'react';
import { useReducedPortfolioMotion } from '../../lib/motion';
export default function MaskRevealUp({ lines, renderLine, stagger = 70, triggerOnView = false }: {
  lines: string[]; renderLine?: (line: string, index: number) => ReactNode;
  stagger?: number; triggerOnView?: boolean;
}) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true });
  const reduced = useReducedPortfolioMotion();
  const play = reduced || !triggerOnView || inView;
  return <span className="smooth-mask" aria-label={lines.join(' ')} ref={ref}>
    {lines.map((line, index) => <span className="smooth-mask-window" key={line}>
      <motion.span className="smooth-mask-line" aria-hidden="true"
        initial={reduced ? false : { opacity: 0, y: 30 }}
        animate={play ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
        transition={{ delay: reduced ? 0 : index * stagger / 1000, duration: reduced ? 0 : 0.45, ease: [0.22, 1, 0.36, 1] }}>
        {renderLine ? renderLine(line, index) : line}
      </motion.span>
    </span>)}
  </span>;
}
