// Adapted from SmoothUI basic-modal (MIT): native dialog provides focus trapping and an inert background.
import { AnimatePresence, motion } from 'motion/react';
import { createPortal } from 'react-dom';
import { useEffect, useRef, type ReactNode } from 'react';
import { X } from 'lucide-react';
import { useReducedPortfolioMotion } from '../../lib/motion';
import { useLocale } from '../../locale';

type Props = { isOpen: boolean; onClose: () => void; title: string; category: string; children: ReactNode };
function ModalSurface({ onClose, title, category, children }: Omit<Props, 'isOpen'>) {
  const {t}=useLocale();
  const dialog = useRef<HTMLDialogElement>(null);
  const closeButton = useRef<HTMLButtonElement>(null);
  const startedOutside = useRef(false);
  const reduced = useReducedPortfolioMotion();
  useEffect(() => {
    const node = dialog.current!;
    const previous = document.activeElement as HTMLElement | null;
    node.showModal();
    document.body.classList.add('modal-open');
    closeButton.current?.focus({ preventScroll: true });
    return () => {
      node.close();
      document.body.classList.remove('modal-open');
      if (previous?.isConnected) previous.focus({ preventScroll: true });
    };
  }, []);
  const outside = (x: number, y: number) => {
    const rect = dialog.current!.getBoundingClientRect();
    return x < rect.left || x > rect.right || y < rect.top || y > rect.bottom;
  };
  return <motion.dialog id="case-dialog" ref={dialog} aria-labelledby="dialog-title" aria-modal="true"
    initial={reduced ? false : { opacity: 0, scale: 0.97, y: 12 }}
    animate={{ opacity: 1, scale: 1, y: 0 }}
    exit={{ opacity: 0, scale: reduced ? 1 : 0.98, y: reduced ? 0 : 8 }}
    transition={{ duration: reduced ? 0 : 0.22, ease: [0.22, 1, 0.36, 1] }}
    onCancel={event => { event.preventDefault(); onClose(); }}
    onKeyDown={event => {
      if (event.key !== 'Tab') return;
      const nodes = [...event.currentTarget.querySelectorAll<HTMLElement>('button:not([disabled]), a[href], [tabindex="0"]')];
      const first = nodes[0], last = nodes.at(-1);
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
    }}
    onPointerDown={event => { startedOutside.current = outside(event.clientX, event.clientY); }}
    onClick={event => { if (startedOutside.current && outside(event.clientX, event.clientY)) onClose(); }}>
    <div className="dialog-topline"><span id="dialog-category" className="eyebrow">{category}</span>
      <motion.button type="button" className="dialog-close" aria-label={t('Закрыть описание проекта')}
        ref={closeButton} onClick={onClose} whileHover={reduced ? undefined : { rotate: 90 }}>
        <X size={24} aria-hidden="true" />
      </motion.button></div>
    <h2 id="dialog-title" tabIndex={-1}>{title}</h2>{children}
  </motion.dialog>;
}
export default function BasicModal({ isOpen, ...props }: Props) {
  if (typeof document === 'undefined') return null;
  return createPortal(<AnimatePresence>{isOpen && <ModalSurface key="case" {...props} />}</AnimatePresence>, document.body);
}
