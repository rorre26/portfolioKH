import { projectKeys, type ProjectKey } from '../data';
import { useLocale } from '../locale';
const titles={hr:'Внедрение HR-сервиса',legal:'Цифровое согласование договоров',marketplaces:'Анализ рентабельности процесса',procurement:'Автоматизация закупок'};
const proof={hr:'Компания перешла на новый процесс; сервисом пользуются 300+ сотрудников.',legal:'Бумажный маршрут заменён цифровым. Объём — около 100 договоров в месяц.',marketplaces:'Определил порог рентабельности и категории, где работа со штрафами не окупается.',procurement:'30+ описанных процессов, 10+ ТЗ и обучение 30 сотрудников.'};
export default function ProjectGallery({onOpen}:{onOpen:(key:ProjectKey)=>void}){
  const {t,cases}=useLocale();
  return <div className="resume-case-grid">{projectKeys.map((key,i)=><article className="resume-case" key={key}><p className="eyebrow">0{i+2} / {t(key==='procurement'?'НПК «ВТСС»':'АЙКОВЕР ПРО').toUpperCase()}</p><h3>{t(titles[key])}</h3><p className="resume-case-contribution">{cases[key].role}</p><p className="resume-case-result"><span className="resume-label">{t('РЕЗУЛЬТАТ / МАСШТАБ')}</span>{t(proof[key])}</p><button id={`open-${key}`} className="text-link" onClick={()=>onOpen(key)} aria-label={`${t('Подробнее: ')}${t(titles[key])}`}>{t('Мои действия и результат')} <span aria-hidden="true">↗</span></button></article>)}</div>;
}
