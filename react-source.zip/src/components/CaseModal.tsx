import { useEffect, useRef } from 'react';
import { email, projectKeys, type ProjectKey } from '../data';
import { useLocale } from '../locale';
import BasicModal from './smoothui/BasicModal';
export default function CaseModal({ project, onClose, onChange }: { project: ProjectKey | null; onClose: () => void; onChange: (key: ProjectKey) => void }) {
  const {t,cases,projectViews,resume}=useLocale();
  // Retain the content while the closing animation finishes.
  const last = useRef<ProjectKey>('hr');
  if (project) last.current = project;
  const key = project || last.current, item = cases[key];
  const previous = useRef(project);
  useEffect(() => {
    if (project && previous.current && previous.current !== project) {
      const title = document.getElementById('dialog-title'); title?.focus({ preventScroll: true });
      document.getElementById('case-dialog')?.scrollTo({ top: 0 });
    } previous.current = project;
  }, [project]);
  return <BasicModal isOpen={project !== null} onClose={onClose} title={item.title} category={`[${projectViews[key].number} / 05] ${item.category}`}>
    <div id="dialog-content">{[['Ситуация', item.problem], ['Моя ответственность', resume.responsibilities[key]], ['Мои действия', item.role], ['Результат', item.result]].map(([heading, text], index) =>
      <section key={heading} className={index === 3 ? 'dialog-result' : undefined}><h3>{t(heading)}</h3><p>{text}</p></section>)}
      <div className="tags">{item.tags.map(tag => <span key={tag}>{tag}</span>)}</div>
    </div><div className="dialog-footer"><button className="dialog-next text-link" onClick={() => onChange(projectKeys[(projectKeys.indexOf(key) + 1) % projectKeys.length])}>{t('Следующий пример →')}</button>
      <a className="action-button" href={`mailto:${email}`}>{t('Обсудить вакансию')} <span aria-hidden="true">↗</span></a></div>
  </BasicModal>;
}
