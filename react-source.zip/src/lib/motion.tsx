import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import { MotionConfig } from 'motion/react';

const MotionSettings = createContext({ enabled: true, systemReduced: false, toggle: () => {} });
export function MotionProvider({ children }: { children: ReactNode }) {
  const [choice, setChoice] = useState(true);
  const [systemReduced, setSystemReduced] = useState(false);
  useEffect(() => {
    const preference = window.matchMedia('(prefers-reduced-motion: reduce)');
    const update = () => setSystemReduced(preference.matches);
    update();
    try { setChoice(sessionStorage.getItem('portfolio-motion') !== 'off'); } catch { /* Optional storage. */ }
    preference.addEventListener('change', update);
    return () => preference.removeEventListener('change', update);
  }, []);
  const enabled = choice && !systemReduced;
  useEffect(() => { document.documentElement.dataset.motion = enabled ? 'on' : 'off'; }, [enabled]);
  const toggle = () => {
    const next = !choice;
    setChoice(next);
    try { sessionStorage.setItem('portfolio-motion', next ? 'on' : 'off'); } catch { /* Optional storage. */ }
  };
  return <MotionSettings.Provider value={{ enabled, systemReduced, toggle }}>
    <MotionConfig reducedMotion={enabled ? 'never' : 'always'}>{children}</MotionConfig>
  </MotionSettings.Provider>;
}
export const useMotionSettings = () => useContext(MotionSettings);
export const useReducedPortfolioMotion = () => !useMotionSettings().enabled;
