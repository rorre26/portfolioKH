import type { KeyboardEvent } from 'react';
export function navigateTabs<T extends string>(event: KeyboardEvent<HTMLButtonElement>, keys: T[], current: T, select: (key: T) => void) {
  const index = keys.indexOf(current);
  let next: number;
  switch (event.key) {
    case 'ArrowRight': case 'ArrowDown': next = (index + 1) % keys.length; break;
    case 'ArrowLeft': case 'ArrowUp': next = (index - 1 + keys.length) % keys.length; break;
    case 'Home': next = 0; break;
    case 'End': next = keys.length - 1; break;
    default: return;
  }
  event.preventDefault(); select(keys[next]);
  event.currentTarget.parentElement?.querySelector<HTMLButtonElement>(`[data-key="${keys[next]}"]`)?.focus({ preventScroll: true });
}
