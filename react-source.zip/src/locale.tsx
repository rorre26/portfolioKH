import { createContext, useContext, useEffect, useRef, useState, type ReactNode } from 'react';
import resumeRu from './resume.json';
import resumeEn from './resume.en.json';
import { cases, modules, stages, projectViews } from './data';
import { casesEn, modulesEn, stagesEn, projectViewsEn } from './data.en';

export type Locale = 'ru' | 'en';
const storageKey = 'portfolio-language';
const en: Record<string, string> = {
  'Перейти к содержанию':'Skip to content','Опыт':'Experience','Компетенции':'Skills','Мой вклад':'My work',
  'Ариф Хадиков — в начало':'Arif Khadikov — home','АРИФ ХАДИКОВ':'ARIF KHADIKOV','АВТОМАТИЗАЦИЯ ПРОЦЕССОВ':'PROCESS AUTOMATION',
  'Основная навигация':'Main navigation','Мобильная навигация':'Mobile navigation','Связаться':'Contact',
  'Закрыть меню':'Close menu','Открыть меню':'Open menu',
  'ПРОФЕССИОНАЛЬНОЕ РЕЗЮМЕ':'PROFESSIONAL RÉSUMÉ','АВТОМАТИЗАЦИЯ / ОПТИМИЗАЦИЯ':'AUTOMATION / OPTIMIZATION',
  'Посмотреть опыт':'Explore experience','Обсудить вакансию':'Discuss an opportunity',
  'Скачать резюме':'Download résumé','Скачать резюме в PDF ↓':'Download résumé PDF ↓','PDF · 2 страницы ↓':'PDF · 2 PAGES ↓',
  'ПРОФЕССИОНАЛЬНЫЙ ПРОФИЛЬ':'PROFESSIONAL PROFILE','года автоматизирую':'years automating','и оптимизирую процессы':'and optimizing processes',
  'Опыт в компании':'Current company','Айковер ПРО':'Icover PRO','АЙКОВЕР ПРО':'ICOVER PRO','С февраля 2025':'Since February 2025',
  'Основные задачи':'Core work','Автоматизация и оптимизация процессов':'Process automation and optimization',
  'Рабочий контекст':'Working with','Бизнес-заказчики, пользователи и команда разработки':'Business stakeholders, users, and developers',
  'Образование':'Education','Прикладная информатика':'Applied Informatics','РЭУ им. Г. В. Плеханова':'Plekhanov University',
  'ОПЫТ · КОМПЕТЕНЦИИ · ЛИЧНЫЙ ВКЛАД':'EXPERIENCE · SKILLS · PERSONAL CONTRIBUTION',
  'Перейти к опыту работы':'Go to work experience',
  'ЛИЧНЫЙ ВКЛАД В ЦИФРАХ':'MY CONTRIBUTION IN NUMBERS',
  'описанных процессов':'documented processes','технических заданий':'technical specifications',
  'За год в Айковер ПРО':'In one year at Icover PRO',
  'пользователей внедрённого HR-сервиса':'users of the HR service I implemented','Мой вклад и результат ↗':'My work and results ↗',
  '[01] / ОПЫТ РАБОТЫ':'[01] / WORK EXPERIENCE','Опыт и ответственность.':'Experience and responsibilities.',
  'ЗОНА ОТВЕТСТВЕННОСТИ':'RESPONSIBILITIES','МОЙ ВКЛАД':'MY CONTRIBUTION','Ещё достижения':'More achievements',
  'Мой вклад в WMS ↗':'My WMS contribution ↗','Внедрение HR-сервиса ↗':'HR service implementation ↗',
  'Подробнее о внедрении ↗':'Implementation details ↗',
  'ОТДЕЛЬНЫЙ ПРОЕКТНЫЙ ОПЫТ':'ADDITIONAL PROJECT EXPERIENCE','Самостоятельные проекты':'Independent projects',
  'Банковские системы, EAM, HR и автоматизация бизнеса':'Banking systems, EAM, HR, and business automation',
  '[02] / КОМПЕТЕНЦИИ':'[02] / SKILLS','Задачи, которые беру на себя.':'The work I take on.',
  'ПОДТВЕРЖДЕНИЕ ИЗ ОПЫТА':'EVIDENCE FROM EXPERIENCE','Примеры применения компетенций':'Examples of skills in practice',
  'ИНСТРУМЕНТЫ В РАБОТЕ':'TOOLS I USE','Дополнительно: ':'Additional: ',
  'Требования':'Requirements','Проектирование':'Design','Внедрение':'Implementation',
  '20+ интервью в банковском проекте':'20+ interviews in a banking project',
  'Собирал требования, спроектировал интеграцию с 1С Документооборот, подготовил инструкции и участвовал в тестировании.':'Gathered requirements, designed an integration with 1C Document Management, prepared instructions, and participated in testing.',
  'Банковский документооборот — в проектном опыте':'Banking document workflows — see project experience',
  'Архитектура и сценарии WMS':'WMS architecture and workflows',
  'Проработал требования и пользовательские сценарии в BPMN, UML и DFD. Сопровождал запуск приёмки на одном складе.':'Defined requirements and user flows using BPMN, UML, and DFD. Supported the launch of receiving at one warehouse.',
  'Посмотреть мой вклад в WMS ↗':'Explore my WMS contribution ↗',
  'Обучение 30 сотрудников':'Training 30 employees',
  'Спроектировал и внедрил согласование закупочных договоров в 1С Документооборот. Обучил сотрудников новым процессам и сценариям.':'Designed and implemented procurement approvals in 1C Document Management. Trained employees to use the new workflows.',
  'Открыть пример внедрения ↗':'View implementation example ↗',
  '[03] / ПРИМЕРЫ МОЕГО ВКЛАДА':'[03] / EXAMPLES OF MY WORK',
  'Опыт, подтверждённый работой.':'Experience demonstrated in practice.',
  'Мои действия, ответственность и результаты в конкретных задачах.':'My role, actions, and results in specific projects.',
  '01 / АЙКОВЕР ПРО':'01 / ICOVER PRO',
  'Проектирование и запуск WMS':'Design and launch of a WMS',
  'Архитектура, требования и сценарии. Приёмка работает на одном складе.':'Architecture, requirements, and workflows. Receiving is live at one warehouse.',
  'Внедрение HR-сервиса':'HR service implementation',
  'Цифровое согласование договоров':'Digital contract approvals',
  'Анализ рентабельности процесса':'Process profitability analysis',
  'Автоматизация закупок':'Procurement automation',
  'НПК «ВТСС»':'HTSS','РЕЗУЛЬТАТ / МАСШТАБ':'RESULT / SCALE',
  'Компания перешла на новый процесс; сервисом пользуются 300+ сотрудников.':'The company adopted the new process; 300+ employees use the service.',
  'Бумажный маршрут заменён цифровым. Объём — около 100 договоров в месяц.':'A digital workflow replaced paper approvals, handling approximately 100 contracts per month.',
  'Определил порог рентабельности и категории, где работа со штрафами не окупается.':'Defined the profitability threshold and identified categories where contesting penalties does not pay off.',
  '30+ описанных процессов, 10+ ТЗ и обучение 30 сотрудников.':'30+ mapped processes, 10+ specifications, and training for 30 employees.',
  'Мои действия и результат':'My work and results','Подробнее: ':'Details: ',
  '[01 / 05] АЙКОВЕР ПРО / СКЛАДСКАЯ ЛОГИСТИКА':'[01 / 05] ICOVER PRO / WAREHOUSE OPERATIONS',
  'WMS с нуля':'WMS from scratch','Спроектировал архитектуру и пользовательские сценарии системы управления складом. Сопровождал запуск первого модуля в продуктив.':'Designed the architecture and user flows for a warehouse management system. Supported the production launch of its first module.',
  'КАРТА МОДУЛЕЙ':'MODULE MAP','НАЖМИТЕ НА УЗЕЛ ↙':'SELECT A MODULE ↙',
  'СИСТЕМА':'SYSTEM','Модули WMS':'WMS modules','ТЕСТИРОВАНИЕ':'IN TESTING','ЧЕТЫРЕ МОДУЛЯ / ОДНА СИСТЕМА':'FOUR MODULES / ONE SYSTEM',
  'СХЕМА ПРОЕКТА':'PROJECT MAP','МОДУЛЬ / ':'MODULE / ','МОЙ ВКЛАД В WMS':'MY WMS CONTRIBUTION',
  'Архитектура системы, требования и пользовательские сценарии в BPMN, UML и DFD. Сопровождение запуска первого модуля.':'System architecture, requirements, and user flows in BPMN, UML, and DFD. Support for the first module launch.',
  'ОТ ТРЕБОВАНИЙ ДО ЗАПУСКА':'FROM REQUIREMENTS TO LAUNCH','Этапы проекта WMS':'WMS project stages',
  '01. Требования':'01. Requirements','02. Решение':'02. Solution','03. Запуск':'03. Launch',
  'Ситуация':'Situation','Моя ответственность':'My responsibility','Мои действия':'My actions','Результат':'Result',
  'Следующий пример →':'Next example →','Закрыть описание проекта':'Close project details',
  'ОБРАЗОВАНИЕ':'EDUCATION','[04] / КОНТАКТ':'[04] / CONTACT','ОБСУДИМ РОЛЬ В ВАШЕЙ КОМАНДЕ':'LET’S DISCUSS A ROLE ON YOUR TEAM',
  'ОБСУДИМ':'LET’S DISCUSS','ВАКАНСИЮ':'AN OPPORTUNITY',
  'Готов обсудить задачи по автоматизации':'I’m open to discussing automation',
  'и оптимизации процессов в вашей команде.':'and process optimization work on your team.',
  'Ариф Хадиков / Автоматизация процессов':'Arif Khadikov / Process automation',
  'Движение: снижено':'Motion: reduced','Движение: вкл':'Motion: on','Движение: выкл':'Motion: off','В начало ↑':'Back to top ↑',
  'Почта скопирована':'Email copied','Выделил почту — скопируйте её вручную':'Email selected — please copy it manually',
  'Не удалось скопировать — повторить':'Copy failed — retry','Скопировать адрес электронной почты':'Copy email address','Копирование адреса':'Copying email',
  'Предложение о работе':'Job opportunity'
};

type LocaleContextValue = {
  locale: Locale; choose: (next: Locale) => void; pending: boolean;
  t: (value: string) => string;
  resume: typeof resumeRu; cases: typeof cases; modules: typeof modules;
  stages: typeof stages; projectViews: typeof projectViews;
};
const LocaleContext = createContext<LocaleContextValue | null>(null);
export function useLocale() {
  const context = useContext(LocaleContext);
  if (!context) throw new Error('LocaleProvider is required');
  return context;
}

export function LocaleProvider({children}:{children:ReactNode}) {
  const [locale,setLocale] = useState<Locale>('ru');
  const [pending,setPending] = useState(false);
  const ruButton = useRef<HTMLButtonElement>(null);
  useEffect(() => {
    try {
      const saved = localStorage.getItem(storageKey);
      if (saved === 'ru' || saved === 'en') setLocale(saved);
      else setPending(true);
    } catch { setPending(true); }
  }, []);
  useEffect(() => {
    document.documentElement.lang=locale;
    document.title=locale==='en'?'Arif Khadikov — process automation and optimization':'Ариф Хадиков — автоматизация и оптимизация процессов';
    document.querySelector<HTMLMetaElement>('meta[name="description"]')?.setAttribute('content',locale==='en'
      ? 'Arif Khadikov has spent four years automating and optimizing processes. Explore his experience, skills, projects, and contact details.'
      : 'Ариф Хадиков — автоматизирую и оптимизирую процессы в течение четырёх лет. Резюме: опыт работы, компетенции, личный вклад в проекты и контакты.');
  },[locale]);
  useEffect(() => {
    if (!pending) return;
    const prior=document.body.style.overflow;
    document.body.style.overflow='hidden';
    ruButton.current?.focus();
    return () => {document.body.style.overflow=prior;};
  },[pending]);
  const choose = (next:Locale) => {
    setLocale(next);setPending(false);
    try {localStorage.setItem(storageKey,next);} catch { /* Preference lasts for this visit. */ }
  };
  const value:LocaleContextValue={
    locale,choose,pending,t:(value)=>locale==='en'?(en[value]??value):value,
    resume:locale==='en'?resumeEn:resumeRu,
    cases:locale==='en'?casesEn:cases,
    modules:locale==='en'?modulesEn as typeof modules:modules,
    stages:locale==='en'?stagesEn:stages,
    projectViews:locale==='en'?projectViewsEn:projectViews
  };
  return <LocaleContext.Provider value={value}>
    <div id="portfolio-shell" inert={pending}>{children}</div>
    {pending&&<div className="language-gate" role="dialog" aria-modal="true" aria-labelledby="language-gate-title" onKeyDown={event=>{
      if(event.key==='Tab'){const buttons=[...event.currentTarget.querySelectorAll<HTMLButtonElement>('button')];if(event.shiftKey&&document.activeElement===buttons[0]){event.preventDefault();buttons.at(-1)?.focus();}else if(!event.shiftKey&&document.activeElement===buttons.at(-1)){event.preventDefault();buttons[0]?.focus();}}
    }}><div className="language-gate-card"><span className="eyebrow">АРИФ ХАДИКОВ / ARIF KHADIKOV</span><h2 id="language-gate-title">Выберите язык<br/><span>Choose a language</span></h2><p>Язык сайта можно изменить в любой момент.<br/>You can switch languages at any time.</p><div className="language-gate-actions"><button ref={ruButton} onClick={()=>choose('ru')} lang="ru">Русский <span>↗</span></button><button onClick={()=>choose('en')} lang="en">English <span>↗</span></button></div></div></div>}
  </LocaleContext.Provider>;
}
