import type { ProjectKey, ModuleKey } from './data';

export const casesEn: Record<ProjectKey, {category:string;title:string;problem:string;role:string;result:string;tags:string[]}> = {
  hr: {
    category: 'ICOVER PRO / HR / AUTOMATION',
    title: 'Leave without manual administration',
    problem: 'After an HR process audit, the company needed to automate leave requests and connect records across its corporate systems.',
    role: 'Audited, designed, and implemented a service for automatic booking in Bitrix24, leave balance calculation, and synchronization with 1C Trade Management.',
    result: 'The company fully moved to the new process. All 300+ employees use the service.',
    tags: ['HR audit', 'Bitrix24', '1C Trade Management', 'Integrations']
  },
  legal: {
    category: 'ICOVER PRO / LEGAL / DOCUMENT WORKFLOWS',
    title: 'Digital contract approvals',
    problem: 'Contracts were approved on paper. The workflow needed to move online while handling approximately 100 contracts per month.',
    role: 'Digitized contract approvals with RPA in Bitrix24. Also designed and introduced a process for protecting the company’s intellectual property rights.',
    result: 'A digital workflow replaced paper approvals. The process handles approximately 100 contracts per month.',
    tags: ['Bitrix24', 'RPA', 'Contracts', 'Process optimization']
  },
  marketplaces: {
    category: 'ICOVER PRO / E-COMMERCE / OPTIMIZATION',
    title: 'Focus on work that pays off',
    problem: 'The team spent over 60 hours per month communicating with marketplaces about penalties. Some of that work was not financially worthwhile.',
    role: 'Analyzed the workflow, set a profitability threshold, and identified product categories for which contesting penalties was not worthwhile.',
    result: 'The team now focuses on cases with a financial return, reducing unproductive work. Before the change, support communication took over 60 hours per month.',
    tags: ['Process analysis', 'Profitability', 'Marketplaces']
  },
  procurement: {
    category: 'HTSS / INDUSTRY / PROCESSES',
    title: 'Connecting processes into a system',
    problem: 'The company’s internal processes were not documented, and procurement contracts were approved on paper.',
    role: 'Documented and linked 30+ business processes in one map. Designed and implemented procurement contract approvals in 1C Document Management, wrote 10+ specifications, and supported delivery.',
    result: 'The company gained a connected process map and a digital contract approval workflow. I trained 30 employees to use the new processes.',
    tags: ['1C Document Management', 'BPMN', 'EPC', 'Camunda', 'Bizagi']
  }
};

export const stagesEn = [
  {title:'Make warehouse operations transparent',text:'Gathered requirements, documented warehouse operations and user flows, and laid the groundwork for managing receiving, shipping, and location-based storage.',caption:'Operations connected in a single model'},
  {title:'Design the architecture and workflows',text:'Designed the WMS architecture and user flows in BPMN, UML, and DFD. Defined module requirements and system interactions.',caption:'Architecture, workflows, and module connections'},
  {title:'Launch the first module in daily operations',text:'Receiving is live at one warehouse; shipping is in testing. Warehouse operations became measurable, revealing downtime and excess hiring. Expansion to a second warehouse is a future step.',caption:'Receiving live · see other statuses below'}
];

export const modulesEn: Record<ModuleKey, {number:string;title:string;status:string;state:string;description:string;value:string;valueLabel:string}> = {
  inbound: {number:'01',title:'Receiving',status:'Live',state:'live',description:'The first WMS module is in daily use at one warehouse.',value:'1 warehouse',valueLabel:'uses the receiving module'},
  outbound: {number:'02',title:'Shipping',status:'In testing',state:'testing',description:'The shipping module is being tested as the warehouse system evolves.',value:'Testing',valueLabel:'current module phase'},
  inventory: {number:'03',title:'Inventory',status:'Planned',state:'planned',description:'Inventory is on the WMS roadmap. The diagram shows its place in the overall system.',value:'Planned',valueLabel:'future WMS development'},
  picking: {number:'04',title:'Picking',status:'Planned',state:'planned',description:'Picking is on the WMS roadmap alongside receiving, shipping, and inventory.',value:'Planned',valueLabel:'future WMS development'}
};

export const projectViewsEn: Record<ProjectKey, {number:string;category:string;description:string;metric:string;metricLabel:string}> = {
  hr: {number:'02',category:'HR / AUTOMATION',description:'Leave request service with balance calculation and system synchronization.',metric:'300+',metricLabel:'employees use the service'},
  legal: {number:'03',category:'LEGAL / DOCUMENT WORKFLOWS',description:'Digital contract approvals replace a paper process.',metric:'~100',metricLabel:'contracts per month'},
  marketplaces: {number:'04',category:'E-COMMERCE / OPTIMIZATION',description:'Marketplace penalty analysis and reduced unproductive work.',metric:'60+ hrs/mo',metricLabel:'workload before optimization'},
  procurement: {number:'05',category:'INDUSTRY / PROCESSES',description:'Connected process map and digital procurement approvals.',metric:'30+',metricLabel:'documented business processes'}
};
